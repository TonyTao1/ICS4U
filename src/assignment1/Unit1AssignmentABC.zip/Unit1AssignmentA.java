package assignment1;

//2026.02.19 TonyTao Unit1Assignment PartA a program that enters the names, costs and quantities of toys you are buying and  print out a summary
import java.io.*;
import java.util.Scanner;

public class Unit1AssignmentA {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numOfToy = 0;
		int amountOfToy = 0;
		double purchaseTotalCostBeforeTax = 0;

		int mostExpensiveItemQuantity = 0;
		String mostExpensiveItemName = "";
		double mostExpensiveItemTotalCost = Double.MIN_VALUE;

		// using string.format
		String summary = String.format("""
				---------------------------------------------------------------------------------------------
				| Here is a summary of your purchases at Wong "R" Us:                                       |
				|                                                                                           |
				| %-38s %12s %14s %17s %6s
				| %-38s %12s %14s %17s %6s
				""", "ITEM", "UNIT COST", "QUANTITY", "TOTAL COST", "|", "----", "---------", "--------", "----------",
				"|");

		do {
			numOfToy++;
			// prompt for toy name, any string could work, but must be less than 30 chars
			// and not empty
			String toyName = promptForToyName(sc, numOfToy);

			// prompt for quantity, must be an integer
			int quantity = promptForQuantity(sc);
			amountOfToy += quantity;

			// must not use nextDouble(), must use nextLine() and parse it to a double, and
			// must check if it's a positive double first
			double unitCost = promptForPrice(sc);

			// print the total price, which is quantity * cost
			double itemTotalPrice = quantity * unitCost;
			if (itemTotalPrice > mostExpensiveItemTotalCost) {
				mostExpensiveItemQuantity = quantity;
				mostExpensiveItemName = toyName;
				mostExpensiveItemTotalCost = itemTotalPrice;
			}
			purchaseTotalCostBeforeTax += itemTotalPrice;
			System.out.printf("The cost for %d %s @ $%.2f each is $%.2f\n", quantity, toyName, unitCost,
					itemTotalPrice);

			// add the toy to the summary, using \t to align the columns, and using
			// String.format to format the string
			summary += String.format("| %-42s$%-15.2f%-16d$%-14.2f |\n", toyName, unitCost, quantity, itemTotalPrice);

			// ask continue or not, and keep asking until it's y or n <- must be do-while
			// loop
		} while (promptForContinuation(sc) == 'y');

		double tax = Math.round(purchaseTotalCostBeforeTax * 0.13 * 100) / 100.0;

		summary += "| ------------------------------------------------------------------------------------      |\n";
		summary += String.format(
				"| Total Cost                                                                $%-15.2f|\n",
				purchaseTotalCostBeforeTax);
		summary += String
				.format("| Tax                                                                       $%-15.2f|\n", tax);
		summary += "| ------------------------------------------------------------------------------------      |\n";
		summary += String.format(
				"| Final Cost                                                                $%-15.2f|\n",
				purchaseTotalCostBeforeTax + tax);
		summary += String.format("|%-91s|\n", " ");
		summary += String.format("| Total # of items bought: %-65d|\n", amountOfToy);
		String lastLine = String.format("Most expensive item: %d %s for $%.2f", mostExpensiveItemQuantity,
				mostExpensiveItemName, mostExpensiveItemTotalCost);
		summary += String.format("| %-88s  |\n", lastLine);
		summary += "---------------------------------------------------------------------------------------------";

		printEndingMessage();
		savingSummary(summary);

		sc.close();
	}

	// helper method of savingSummary
	// save receipt to summary.txt, print
	public static void savingSummary(String summary) {
		try {
			FileWriter fw = new FileWriter("summary.txt");
			fw.write(summary + "\n");
			fw.close();
			System.out.println("(Your receipt is saved in receipt.txt.)");
		} catch (IOException e) {
			System.out.println("An error occurred while saving the summary.");
		}
	}

	// return true if input is a valid quantity (positive integer), otherwise return
	// false
	public static boolean isValidateQuantity(String input) {
		try {
			int quantity = Integer.parseInt(input);
			return quantity > 0 && quantity <= 9999;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	// keep asking for quantity until it's valid, then return the quantity as an
	// integer
	public static int promptForQuantity(Scanner sc) {
		// scan the number of toy
		String input;
		do {
			System.out.print("How many of this toy are you buying?: ");
			input = sc.nextLine();
		} while (!isValidateQuantity(input));
		return Integer.parseInt(input);
	}

	// return true if input is a valid price (positive double), otherwise return
	// false
	public static boolean isValidatePrice(String input) {
		// scan the input to see if it is valid price
		try {
			double price = Double.parseDouble(input);
			price = Math.round(price * 100) / 100.0; // round to 2 decimal places
			return price > 0 && price <= 99999.99; // validate the rounded price
		} catch (NumberFormatException e) {
			return false;
		}
	}

	// keep asking for price until it's valid, then return the price as a double
	public static double promptForPrice(Scanner sc) {
		// scan the price
		String input;
		do {
			System.out.print("Please enter the cost of this toy: $");
			input = sc.nextLine();
		} while (!isValidatePrice(input));
		return Math.round(Double.parseDouble(input) * 100) / 100.0;
	}

	// return true if input is a valid toy name (less than 30 chars and not empty),
	// otherwise return false
	public static boolean isValidateToyName(String input) {
		// scan the toy name to see if it is in the range
		return input.length() > 0 && input.length() <= 30;
	}

	// keep asking for toy name that is less than 30 chars until it's valid, then
	// return the toy name as a string
	public static String promptForToyName(Scanner sc, int numOfToy) {
		// scan the name of the toy
		String input;
		do {
			System.out.print("Please enter the name of the toy #" + numOfToy + ": ");
			input = sc.nextLine();
		} while (!isValidateToyName(input));
		// return the number of toy
		return input;
	}

	public static char promptForContinuation(Scanner sc) {
		// to ask if the user need to buy anything more
		String input;
		do {
			System.out.print("Are you buying anymore toys? (y/n): ");
			input = sc.nextLine().toLowerCase();
			System.out.println();
		} while (!input.equals("y") && !input.equals("n"));
		return input.charAt(0);
		// return the string into char
	}

	public static void printEndingMessage() {
		// print the ending message
		System.out.println("Thank you for shopping at Wong \"R\" Us!");
	}
}
